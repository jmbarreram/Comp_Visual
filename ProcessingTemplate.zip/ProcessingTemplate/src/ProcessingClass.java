import processing.core.*; //2D 

//3.14f 0.5f 1.0f

public class ProcessingClass extends PApplet{
	
	static final int SIZE_X = 640;
	static final int SIZE_Y = 360;
	static final int BCKGND = 255;
	
	public static void main(String[] args){
		PApplet.main(ProcessingClass.class.getName());
	}
	
	public void settings(){
		size(SIZE_X,SIZE_Y);
		//size(SIZE_X,SIZE_Y,P3D); //3D
	}
	
	public void setup(){
		//Do when start
		
		background(BCKGND);
	}
	
	public void draw(){
		//Drawing loop
		
	}

}
